package com.marvik.apis.core.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.marvik.apis.core.utilities.Utilities;

/**
 * Created by victor on 11/7/2015.
 */
public abstract class ActivityWrapper extends AppCompatActivity {

    private Utilities utilities;

     public Utilities getUtils() {
        return utilities;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initAll();
        onCreateActivity(savedInstanceState);

    }

    @Override
    protected void onResume() {
        super.onResume();
        onResumeActivity();
    }

    @Override
    protected void onPause() {
        super.onPause();
        onPauseActivity();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        onDestroyActivity();
    }

    protected abstract void onCreateActivity(Bundle savedInstanceState);

    protected abstract void onResumeActivity();

    protected abstract void onPauseActivity();

    protected abstract void onDestroyActivity();

    private void initAll() {
        utilities = new Utilities(ActivityWrapper.this);
    }

}
